# Get the list of buckets
buckets=$(gsutil ls)

# Loop through each bucket and calculate its total size in GB
for bucket in $buckets; do
  totalSize=$(gsutil du -s $bucket | awk '{print $1}')
  totalSizeGB=$(echo "scale=2; $totalSize / (1024 * 1024 * 1024)" | bc)
  echo "$bucket: $totalSizeGB GB"
done
